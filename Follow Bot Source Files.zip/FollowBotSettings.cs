using GameHelper.Plugin;

namespace FollowBot
{
    /// <summary>
    /// FollowBot plugin settings
    /// </summary>
    public sealed class FollowBotSettings : IPSettings
    {
        /// <summary>
        /// Enable/disable follow bot system
        /// </summary>
        public bool IsEnabled = false;

        /// <summary>
        /// The name of the player to target specifically.
        /// </summary>
        public string TargetPlayerName = "";

        /// <summary>
        /// Key to press when target is found (e.g., "q", "w", "e", "r", "t")
        /// </summary>
        public string KeyToPress = "";

        /// <summary>
        /// Stop distance - key will only be pressed when target is further than this
        /// </summary>
        public int StopDistance = 15;

        /// <summary>
        /// Virtual key code for toggle (F1=112, F2=113, etc.)
        /// </summary>
        public int ToggleKey = 113; // F2 by default

        public int MinKeyPressDelay = 50;
        public int MaxKeyPressDelay = 125;
    }
}