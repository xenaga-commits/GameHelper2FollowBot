using System;
using System.Numerics;
using System.Runtime.InteropServices;
using ImGuiNET;
using GameHelper;
using GameHelper.Plugin;
using GameHelper.RemoteEnums;
using GameHelper.RemoteEnums.Entity;
using GameHelper.RemoteObjects.Components;
using GameHelper.RemoteObjects.States.InGameStateObjects;
using GameHelper.Utils;

namespace FollowBot
{
    public sealed class FollowBot : PCore<FollowBotSettings>
    {
        // ===== Windows API Imports for Input Simulation =====
        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int X, int Y);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        [DllImport("user32.dll")]
        private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        [DllImport("user32.dll")]
        private static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint cButtons, UIntPtr dwExtraInfo);

        // Constants for key and mouse events
        private const uint KEYEVENTF_KEYDOWN = 0x0000;
        private const uint KEYEVENTF_KEYUP = 0x0002;
        private const uint MOUSEEVENTF_LEFTDOWN = 0x02;
        private const uint MOUSEEVENTF_LEFTUP = 0x04;

        // ===== Internal State Fields =====
        private bool wasToggleKeyPressed = false;
        private bool isMovementKeyPressed = false;
        private DateTime lastPortalClickTime = DateTime.MinValue;

        // ===== Settings UI =====
        public override void DrawSettings()
        {
            ImGui.Text("=== FOLLOW BOT SETTINGS ===");
            ImGui.TextWrapped("This plugin automatically follows a specified leader player by pressing and holding a movement key.");

            ImGui.Separator();

            ImGui.InputText("Leader Player Name", ref Settings.TargetPlayerName, 256);
            ImGuiHelper.ToolTip("Enter the exact name of the leader's character.");

            ImGui.InputText("Movement Key", ref Settings.KeyToPress, 2);
            ImGuiHelper.ToolTip("Enter the single key used for movement (e.g., 'T', 'Q').");

            ImGui.SliderInt("Stop Distance", ref Settings.StopDistance, 5, 100);
            ImGuiHelper.ToolTip("The bot will stop moving when it is this close to the leader.");
            
            ImGui.Separator();
            ImGui.Text("Toggle Key:");
            ImGui.RadioButton("F1", ref Settings.ToggleKey, 112); ImGui.SameLine();
            ImGui.RadioButton("F2", ref Settings.ToggleKey, 113); ImGui.SameLine();
            ImGui.RadioButton("F3", ref Settings.ToggleKey, 114); ImGui.SameLine();
            ImGui.RadioButton("F4", ref Settings.ToggleKey, 115);
            
            ImGui.Separator();
            ImGui.Checkbox("Enable Follow Bot", ref Settings.IsEnabled);
            ImGuiHelper.ToolTip("Enable or disable all bot functionality.");
        }

        // ===== Plugin Lifecycle Methods =====
        public override void OnEnable(bool isGameOpened) { }
        public override void OnDisable() => ReleaseMovementKey();
        public override void SaveSettings() { } // Provide an empty implementation

        // ===== Core Update Loop (called every frame) =====
        public override void DrawUI()
        {
            HandleToggleKey();

            if (!Settings.IsEnabled || Core.States.GameCurrentState != GameStateTypes.InGameState || !Core.Process.Foreground)
            {
                ReleaseMovementKey();
                return;
            }

            var currentArea = Core.States.InGameStateObject.CurrentAreaInstance;
            var player = currentArea.Player;
            var leader = FindLeaderByName(currentArea);

            if (leader != null &&
                player.TryGetComponent<Render>(out var playerRender) &&
                leader.TryGetComponent<Render>(out var leaderRender))
            {
                var playerPos = new Vector2(playerRender.GridPosition.X, playerRender.GridPosition.Y);
                var leaderPos = new Vector2(leaderRender.GridPosition.X, leaderRender.GridPosition.Y);
                var distance = Vector2.Distance(playerPos, leaderPos);

                if (distance > Settings.StopDistance)
                {
                    MoveMouseToLeader(leaderRender);
                    PressAndHoldMovementKey();
                }
                else
                {
                    ReleaseMovementKey();
                }
            }
            else
            {
                ReleaseMovementKey();
                
                var areaDetails = Core.States.InGameStateObject.CurrentWorldInstance.AreaDetails;
                if (areaDetails.IsHideout)
                {
                    var portal = FindPortal(currentArea);
                    if (portal != null && portal.TryGetComponent<Render>(out var portalRender))
                    {
                        ClickOnPortal(portalRender);
                    }
                }
            }
        }

        // ===== Entity Finding (Optimized) =====
        private Entity FindLeaderByName(AreaInstance currentArea)
        {
            if (string.IsNullOrWhiteSpace(Settings.TargetPlayerName))
            {
                return null;
            }

            foreach (var entity in currentArea.AwakeEntities.Values)
            {
                if (entity?.EntityType == EntityTypes.Player &&
                    entity.IsValid &&
                    entity.TryGetComponent<Player>(out var playerComponent) &&
                    playerComponent.Name.Equals(Settings.TargetPlayerName, StringComparison.OrdinalIgnoreCase))
                {
                    return entity;
                }
            }

            return null;
        }

        private Entity FindPortal(AreaInstance currentArea)
        {
            foreach (var entity in currentArea.AwakeEntities.Values)
            {
                if (entity != null && entity.IsValid &&
                    entity.Path.Equals("Metadata/MiscellaneousObjects/MultiplexPortal", StringComparison.OrdinalIgnoreCase))
                {
                    return entity;
                }
            }
            return null;
        }

        // ===== Mouse and Key Handling =====
        private void ClickOnPortal(Render portalRender)
        {
            if ((DateTime.Now - lastPortalClickTime).TotalSeconds < 3)
            {
                return; // 3-second cooldown to prevent spam clicking
            }

            var gameWindow = Core.Process.WindowArea;
            var portalScreenPos = Core.States.InGameStateObject.CurrentWorldInstance.WorldToScreen(portalRender.WorldPosition);

            if (portalScreenPos.X > 0 && portalScreenPos.Y > 0 &&
                portalScreenPos.X < gameWindow.Width && portalScreenPos.Y < gameWindow.Height)
            {
                int absoluteX = gameWindow.X + (int)portalScreenPos.X;
                int absoluteY = gameWindow.Y + (int)portalScreenPos.Y;
                
                SetCursorPos(absoluteX, absoluteY);

                mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero);
                mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);
                
                lastPortalClickTime = DateTime.Now;
            }
        }

        private void MoveMouseToLeader(Render leaderRender)
        {
            var gameWindow = Core.Process.WindowArea;
            var leaderScreenPos = Core.States.InGameStateObject.CurrentWorldInstance.WorldToScreen(leaderRender.WorldPosition);

            if (leaderScreenPos.X > 0 && leaderScreenPos.Y > 0 &&
                leaderScreenPos.X < gameWindow.Width && leaderScreenPos.Y < gameWindow.Height)
            {
                int absoluteX = gameWindow.X + (int)leaderScreenPos.X;
                int absoluteY = gameWindow.Y + (int)leaderScreenPos.Y;
                SetCursorPos(absoluteX, absoluteY);
            }
        }

        private void PressAndHoldMovementKey()
        {
            if (!isMovementKeyPressed && IsValidKey(Settings.KeyToPress))
            {
                byte keyCode = (byte)char.ToUpper(Settings.KeyToPress[0]);
                keybd_event(keyCode, 0, KEYEVENTF_KEYDOWN, UIntPtr.Zero);
                isMovementKeyPressed = true;
            }
        }

        private void ReleaseMovementKey()
        {
            if (isMovementKeyPressed && IsValidKey(Settings.KeyToPress))
            {
                byte keyCode = (byte)char.ToUpper(Settings.KeyToPress[0]);
                keybd_event(keyCode, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                isMovementKeyPressed = false;
            }
        }

        private bool IsValidKey(string key) => !string.IsNullOrEmpty(key);

        // ===== Toggle Key Handling =====
        private void HandleToggleKey()
        {
            bool isToggleKeyPressedNow = (GetAsyncKeyState(Settings.ToggleKey) & 0x8000) != 0;
            if (isToggleKeyPressedNow && !wasToggleKeyPressed)
            {
                Settings.IsEnabled = !Settings.IsEnabled;
            }
            wasToggleKeyPressed = isToggleKeyPressedNow;
        }
    }
}

